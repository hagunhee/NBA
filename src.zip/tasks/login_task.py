"""
로그인 작업
"""

import asyncio
from typing import Dict, Any, List

from .base_task import BaseTask, TaskType, TaskResult


class LoginTask(BaseTask):
    """네이버 로그인 작업"""

    def __init__(self, name: str = "네이버 로그인"):
        super().__init__(TaskType.LOGIN, name, "네이버 계정으로 로그인합니다.")

        # 기본 파라미터
        self.parameters = {
            "user_id": "",
            "password": "",
            "keep_login": True,
            "retry_on_captcha": False,
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """로그인 실행"""
        try:
            # 파라미터 가져오기
            user_id = self.get_parameter("user_id")
            password = self.get_parameter("password")
            keep_login = self.get_parameter("keep_login", True)

            if not user_id or not password:
                return TaskResult(
                    success=False, message="아이디 또는 비밀번호가 설정되지 않았습니다."
                )

            # 네이버 로그인 페이지로 이동
            await browser_manager.navigate("https://nid.naver.com/nidlogin.login")
            await asyncio.sleep(2)

            # 아이디 입력
            await browser_manager.type_text("#id", user_id)
            await asyncio.sleep(0.5)

            # 비밀번호 입력
            await browser_manager.type_text("#pw", password)
            await asyncio.sleep(0.5)

            # 로그인 상태 유지 체크
            if keep_login:
                await browser_manager.click(".keep_check")
                await asyncio.sleep(0.5)

            # 로그인 버튼 클릭
            await browser_manager.click("#log\\.login")
            await asyncio.sleep(3)

            # 로그인 결과 확인
            current_url = await browser_manager.get_current_url()

            if "naver.com" in current_url and "nid.naver.com" not in current_url:
                # 로그인 성공
                # 사용자 정보 가져오기
                user_info = await self._get_user_info(browser_manager)

                return TaskResult(
                    success=True, message="로그인 성공", data={"user_info": user_info}
                )
            elif "captcha" in current_url:
                return TaskResult(
                    success=False,
                    message="캡차 인증이 필요합니다.",
                    data={"captcha_required": True},
                )
            else:
                return TaskResult(
                    success=False,
                    message="로그인 실패 - 아이디 또는 비밀번호를 확인하세요.",
                )

        except Exception as e:
            return TaskResult(success=False, message=f"로그인 중 오류 발생: {str(e)}")

    async def _get_user_info(self, browser_manager: Any) -> Dict[str, str]:
        """사용자 정보 가져오기"""
        try:
            # 네이버 메인으로 이동
            await browser_manager.navigate("https://www.naver.com")
            await asyncio.sleep(2)

            # 사용자 닉네임 가져오기
            nickname = await browser_manager.get_text(".user_name")

            return {"nickname": nickname, "logged_in": True}
        except:
            return {"nickname": "Unknown", "logged_in": True}

    def validate_parameters(self) -> bool:
        """파라미터 검증"""
        user_id = self.get_parameter("user_id")
        password = self.get_parameter("password")

        return bool(user_id and password)

    def get_estimated_duration(self) -> int:
        """예상 소요 시간"""
        return 10  # 10초


class CheckNewPostsTask(BaseTask):
    """이웃 새글 확인 작업"""

    def __init__(self, name: str = "이웃 새글 확인"):
        super().__init__(TaskType.CHECK_POSTS, name, "이웃들의 새 글을 확인합니다.")

        # 기본 파라미터
        self.parameters = {"max_posts": 20, "filter_keywords": []}

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """새글 확인 실행"""
        try:
            # 이웃 새글 페이지로 이동
            await browser_manager.navigate(
                "https://section.blog.naver.com/BlogHome.naver"
            )
            await asyncio.sleep(3)

            # 포스트 목록 가져오기
            posts = await self._get_neighbor_posts(browser_manager)

            # 필터링
            filter_keywords = self.get_parameter("filter_keywords", [])
            if filter_keywords:
                posts = self._filter_posts(posts, filter_keywords)

            # 최대 개수 제한
            max_posts = self.get_parameter("max_posts", 20)
            posts = posts[:max_posts]

            return TaskResult(
                success=True,
                message=f"{len(posts)}개의 새 글을 발견했습니다.",
                data={"posts": posts},
            )

        except Exception as e:
            return TaskResult(
                success=False, message=f"새글 확인 중 오류 발생: {str(e)}"
            )

    async def _get_neighbor_posts(self, browser_manager: Any) -> List[Dict[str, str]]:
        """이웃 포스트 목록 가져오기"""
        posts = []

        # 포스트 요소들 찾기
        post_elements = await browser_manager.find_elements(".title_post")

        for element in post_elements:
            try:
                # 제목과 URL 가져오기
                title = await browser_manager.get_text_from_element(element)
                parent_link = await browser_manager.find_parent_link(element)

                if parent_link:
                    url = await browser_manager.get_attribute_from_element(
                        parent_link, "href"
                    )

                    # 블로거 이름 찾기
                    blogger = await self._get_blogger_name(browser_manager, element)

                    posts.append({"title": title, "url": url, "blogger": blogger})
            except:
                continue

        return posts

    async def _get_blogger_name(self, browser_manager: Any, title_element: Any) -> str:
        """블로거 이름 가져오기"""
        try:
            container = await browser_manager.find_parent(title_element, levels=2)
            blogger_elem = await browser_manager.find_element_in(
                container, ".nick, .name"
            )
            return await browser_manager.get_text_from_element(blogger_elem)
        except:
            return "Unknown"

    def _filter_posts(self, posts: List[Dict], keywords: List[str]) -> List[Dict]:
        """키워드로 포스트 필터링"""
        if not keywords:
            return posts

        filtered = []
        for post in posts:
            for keyword in keywords:
                if keyword.lower() in post["title"].lower():
                    filtered.append(post)
                    break

        return filtered

    def validate_parameters(self) -> bool:
        """파라미터 검증"""
        max_posts = self.get_parameter("max_posts", 20)
        return isinstance(max_posts, int) and max_posts > 0

    def get_estimated_duration(self) -> int:
        """예상 소요 시간"""
        return 5  # 5초


class WriteCommentTask(BaseTask):
    """댓글 작성 작업"""

    def __init__(self, name: str = "댓글 작성"):
        super().__init__(
            TaskType.WRITE_COMMENT, name, "블로그 포스트에 댓글을 작성합니다."
        )

        # 기본 파라미터
        self.parameters = {
            "post_url": "",
            "comment_text": "",
            "auto_generate": True,
            "comment_style": "친근함",
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """댓글 작성 실행"""
        try:
            post_url = self.get_parameter("post_url")
            if not post_url:
                # 컨텍스트에서 포스트 URL 가져오기
                posts = context.get("posts", [])
                if posts:
                    post_url = posts[0]["url"]
                else:
                    return TaskResult(
                        success=False, message="댓글을 작성할 포스트 URL이 없습니다."
                    )

            # 포스트로 이동
            await browser_manager.navigate(post_url)
            await asyncio.sleep(3)

            # 포스트 내용 읽기
            post_content = await self._read_post_content(browser_manager)

            # 댓글 생성 또는 가져오기
            comment_text = self.get_parameter("comment_text")
            if not comment_text and self.get_parameter("auto_generate", True):
                comment_text = await self._generate_comment(post_content)

            if not comment_text:
                return TaskResult(success=False, message="댓글 내용이 없습니다.")

            # 댓글 작성
            success = await self._write_comment(browser_manager, comment_text)

            if success:
                return TaskResult(
                    success=True,
                    message="댓글 작성 완료",
                    data={"comment": comment_text, "post_url": post_url},
                )
            else:
                return TaskResult(success=False, message="댓글 작성 실패")

        except Exception as e:
            return TaskResult(
                success=False, message=f"댓글 작성 중 오류 발생: {str(e)}"
            )

    async def _read_post_content(self, browser_manager: Any) -> Dict[str, str]:
        """포스트 내용 읽기"""
        try:
            # iframe 전환
            await browser_manager.switch_to_frame("#mainFrame")

            # 제목
            title = await browser_manager.get_text(".se-title-text")

            # 본문
            content = await browser_manager.get_text(".se-main-container")

            # 메인 프레임으로 복귀
            await browser_manager.switch_to_default_content()

            return {"title": title, "content": content[:1000]}  # 처음 1000자만
        except:
            return {"title": "", "content": ""}

    async def _generate_comment(self, post_content: Dict[str, str]) -> str:
        """댓글 자동 생성"""
        # 여기서는 간단한 템플릿 기반 댓글 생성
        # 실제로는 AI API를 사용할 수 있음

        templates = [
            "좋은 글 잘 읽었습니다! 😊",
            "유익한 정보 감사합니다!",
            "도움이 많이 되었어요. 감사합니다!",
            f"{post_content['title']} 정말 흥미롭네요!",
            "좋은 내용 공유해주셔서 감사해요~",
        ]

        import random

        return random.choice(templates)

    async def _write_comment(self, browser_manager: Any, comment_text: str) -> bool:
        """댓글 작성"""
        try:
            # 페이지 하단으로 스크롤
            await browser_manager.scroll_to_bottom()
            await asyncio.sleep(2)

            # 댓글 iframe 찾기
            await browser_manager.switch_to_frame("#commentIframe")

            # 댓글 입력란 클릭
            await browser_manager.click(".u_cbox_text")
            await asyncio.sleep(1)

            # 댓글 입력
            await browser_manager.type_text(".u_cbox_text", comment_text)
            await asyncio.sleep(1)

            # 등록 버튼 클릭
            await browser_manager.click(".u_cbox_btn_upload")
            await asyncio.sleep(2)

            # 메인 프레임으로 복귀
            await browser_manager.switch_to_default_content()

            return True

        except Exception as e:
            print(f"댓글 작성 실패: {e}")
            return False

    def validate_parameters(self) -> bool:
        """파라미터 검증"""
        # URL이 있거나 자동 생성이 켜져 있으면 OK
        return bool(self.get_parameter("post_url")) or self.get_parameter(
            "auto_generate", True
        )

    def get_estimated_duration(self) -> int:
        """예상 소요 시간"""
        return 15  # 15초
