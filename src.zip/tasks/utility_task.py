"""
유틸리티 작업들 - 좋아요, 대기, 스크롤 등
"""

import time
import random
from typing import Dict, Any
from tasks.base_task import BaseTask, TaskType, TaskResult
from automation.naver_actions import NaverActions


class LikeTask(BaseTask):
    """좋아요 클릭 작업"""

    def __init__(self, name: str = "좋아요 클릭"):
        super().__init__(TaskType.CLICK_LIKE, name, "포스트에 좋아요를 클릭합니다.")

        self.parameters = {
            "post_url": "",  # 특정 URL (없으면 현재 페이지)
            "wait_after": 2,  # 클릭 후 대기 시간
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """좋아요 클릭 실행"""
        try:
            # 포스트 URL 확인
            post_url = self.get_parameter("post_url")
            if post_url:
                browser_manager.navigate(post_url, wait_time=3)

            # NaverActions 인스턴스 생성
            naver = NaverActions(browser_manager)

            # 좋아요 클릭
            success = naver.click_like()

            if success:
                # 클릭 후 대기
                wait_time = self.get_parameter("wait_after", 2)
                time.sleep(wait_time)

                return TaskResult(
                    success=True,
                    message="좋아요 클릭 완료",
                    data={"liked_url": browser_manager.get_current_url()},
                )
            else:
                return TaskResult(
                    success=False,
                    message="좋아요 버튼을 찾을 수 없거나 이미 클릭되었습니다.",
                )

        except Exception as e:
            return TaskResult(success=False, message=f"좋아요 클릭 중 오류: {str(e)}")

    def validate_parameters(self) -> bool:
        wait_after = self.get_parameter("wait_after", 2)
        return isinstance(wait_after, (int, float)) and wait_after >= 0

    def get_estimated_duration(self) -> int:
        return 5  # 페이지 로드 + 클릭 + 대기


class WaitTask(BaseTask):
    """대기 작업"""

    def __init__(self, name: str = "대기"):
        super().__init__(TaskType.WAIT, name, "지정된 시간만큼 대기합니다.")

        self.parameters = {
            "wait_time": 10,  # 대기 시간 (초)
            "random_range": 0,  # 랜덤 범위 (+/- 초)
            "message": "",  # 대기 중 표시할 메시지
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """대기 실행"""
        try:
            wait_time = self.get_parameter("wait_time", 10)
            random_range = self.get_parameter("random_range", 0)
            message = self.get_parameter("message", "")

            # 실제 대기 시간 계산
            if random_range > 0:
                actual_wait = wait_time + random.uniform(-random_range, random_range)
                actual_wait = max(0, actual_wait)  # 음수 방지
            else:
                actual_wait = wait_time

            # 대기
            display_msg = message or f"{actual_wait:.1f}초 대기 중..."
            print(display_msg)
            time.sleep(actual_wait)

            return TaskResult(
                success=True,
                message=f"{actual_wait:.1f}초 대기 완료",
                data={"waited_seconds": actual_wait},
            )

        except Exception as e:
            return TaskResult(success=False, message=f"대기 중 오류: {str(e)}")

    def validate_parameters(self) -> bool:
        wait_time = self.get_parameter("wait_time", 10)
        random_range = self.get_parameter("random_range", 0)

        if not isinstance(wait_time, (int, float)) or wait_time < 0:
            return False
        if not isinstance(random_range, (int, float)) or random_range < 0:
            return False

        return True

    def get_estimated_duration(self) -> int:
        return int(self.get_parameter("wait_time", 10))


class ScrollReadTask(BaseTask):
    """스크롤 읽기 작업"""

    def __init__(self, name: str = "스크롤 읽기"):
        super().__init__(TaskType.SCROLL_READ, name, "포스트를 스크롤하며 읽습니다.")

        self.parameters = {
            "duration": 60,  # 읽기 시간 (초)
            "scroll_speed": "medium",  # slow, medium, fast
            "post_url": "",  # 특정 URL (없으면 현재 페이지)
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """스크롤 읽기 실행"""
        try:
            # 포스트 URL 확인
            post_url = self.get_parameter("post_url")
            if post_url:
                browser_manager.navigate(post_url, wait_time=3)

            duration = self.get_parameter("duration", 60)
            scroll_speed = self.get_parameter("scroll_speed", "medium")

            # 자연스러운 스크롤
            browser_manager.natural_scroll(duration, scroll_speed)

            return TaskResult(
                success=True,
                message=f"{duration}초 동안 포스트를 읽었습니다.",
                data={
                    "read_url": browser_manager.get_current_url(),
                    "duration": duration,
                },
            )

        except Exception as e:
            return TaskResult(success=False, message=f"스크롤 읽기 중 오류: {str(e)}")

    def validate_parameters(self) -> bool:
        duration = self.get_parameter("duration", 60)
        scroll_speed = self.get_parameter("scroll_speed", "medium")

        if not isinstance(duration, (int, float)) or duration <= 0:
            return False
        if scroll_speed not in ["slow", "medium", "fast"]:
            return False

        return True

    def get_estimated_duration(self) -> int:
        return int(self.get_parameter("duration", 60))


class GoToUrlTask(BaseTask):
    """URL 이동 작업"""

    def __init__(self, name: str = "URL 이동"):
        super().__init__(TaskType.GOTO_URL, name, "지정된 URL로 이동합니다.")

        self.parameters = {
            "url": "",  # 이동할 URL
            "wait_after": 3,  # 이동 후 대기 시간
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """URL 이동 실행"""
        try:
            url = self.get_parameter("url")
            if not url:
                return TaskResult(
                    success=False, message="이동할 URL이 지정되지 않았습니다."
                )

            wait_after = self.get_parameter("wait_after", 3)

            # URL로 이동
            success = browser_manager.navigate(url, wait_time=wait_after)

            if success:
                return TaskResult(
                    success=True,
                    message=f"URL 이동 완료: {url}",
                    data={"navigated_url": url},
                )
            else:
                return TaskResult(success=False, message="URL 이동 실패")

        except Exception as e:
            return TaskResult(success=False, message=f"URL 이동 중 오류: {str(e)}")

    def validate_parameters(self) -> bool:
        url = self.get_parameter("url")
        wait_after = self.get_parameter("wait_after", 3)

        if not url or not isinstance(url, str):
            return False
        if not isinstance(wait_after, (int, float)) or wait_after < 0:
            return False

        # 기본적인 URL 형식 검증
        if not url.startswith(("http://", "https://")):
            return False

        return True

    def get_estimated_duration(self) -> int:
        return int(self.get_parameter("wait_after", 3)) + 2  # 로딩 시간 포함


class LoopTask(BaseTask):
    """반복 작업 컨테이너"""

    def __init__(self, name: str = "반복 작업"):
        super().__init__(
            TaskType.CUSTOM, name, "하위 작업들을 지정된 횟수만큼 반복합니다."
        )

        self.parameters = {
            "repeat_count": 1,  # 반복 횟수
            "sub_tasks": [],  # 반복할 작업들
        }

    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """반복 실행"""
        try:
            repeat_count = self.get_parameter("repeat_count", 1)
            sub_tasks = self.get_parameter("sub_tasks", [])

            if not sub_tasks:
                return TaskResult(success=False, message="반복할 작업이 없습니다.")

            total_executed = 0
            failed_count = 0

            for i in range(repeat_count):
                print(f"반복 {i+1}/{repeat_count} 시작")

                for task in sub_tasks:
                    result = await task.execute(browser_manager, context)
                    total_executed += 1

                    if not result.success:
                        failed_count += 1
                        print(f"작업 실패: {task.name} - {result.message}")

                # 반복 간 대기
                if i < repeat_count - 1:
                    time.sleep(2)

            return TaskResult(
                success=failed_count == 0,
                message=f"{repeat_count}회 반복 완료 (실행: {total_executed}, 실패: {failed_count})",
                data={"total_executed": total_executed, "failed_count": failed_count},
            )

        except Exception as e:
            return TaskResult(success=False, message=f"반복 실행 중 오류: {str(e)}")

    def validate_parameters(self) -> bool:
        repeat_count = self.get_parameter("repeat_count", 1)
        sub_tasks = self.get_parameter("sub_tasks", [])

        if not isinstance(repeat_count, int) or repeat_count <= 0:
            return False
        if not isinstance(sub_tasks, list):
            return False

        return True

    def get_estimated_duration(self) -> int:
        repeat_count = self.get_parameter("repeat_count", 1)
        sub_tasks = self.get_parameter("sub_tasks", [])

        if not sub_tasks:
            return 0

        # 하위 작업들의 예상 시간 합계
        sub_duration = sum(task.get_estimated_duration() for task in sub_tasks)
        return sub_duration * repeat_count
