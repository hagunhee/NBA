"""
작업 팩토리 - 의존성 주입 패턴
파일 위치: src/tasks/task_factory.py
"""

import logging
from typing import Dict, Any, Optional, Type, List
from dataclasses import dataclass, field

from automation.browser_manager import BrowserManager, BrowserConfig
from core.config import Config
from core.security import SecurityManager

# 작업 임포트
from tasks.base_task import BaseTask, TaskType

# 각 파일에서 필요한 작업만 import (중복 제거)
from tasks.login_task import LoginTask  # login_task.py에서 LoginTask만
from tasks.check_posts_task import CheckNewPostsTask  # 상세 버전 사용
from tasks.comment_task import WriteCommentTask  # AI 기능이 있는 상세 버전 사용

# utility_task.py에서 모든 유틸리티 작업
from tasks.utility_task import LikeTask, WaitTask, ScrollReadTask, GoToUrlTask, LoopTask


@dataclass
class TaskDependencies:
    """작업 의존성 컨테이너"""

    browser_manager: Optional[BrowserManager] = None
    config: Optional[Config] = None
    security_manager: Optional[SecurityManager] = None
    logger: Optional[logging.Logger] = None
    context: Dict[str, Any] = field(default_factory=dict)


class TaskFactory:
    """
    작업 팩토리 - 의존성 주입을 통한 작업 생성

    이 클래스는 작업 생성을 중앙화하고 필요한 의존성을 주입합니다.
    """

    def __init__(
        self,
        browser_manager: Optional[BrowserManager] = None,
        config: Optional[Config] = None,
        security_manager: Optional[SecurityManager] = None,
        logger: Optional[logging.Logger] = None,
    ):
        self.browser_manager = browser_manager
        self.config = config or Config()
        self.security_manager = security_manager or SecurityManager()
        self.logger = logger or logging.getLogger(__name__)

        # 작업 타입별 클래스 매핑
        self._task_classes: Dict[TaskType, Type[BaseTask]] = {
            TaskType.LOGIN: LoginTask,
            TaskType.CHECK_POSTS: CheckNewPostsTask,
            TaskType.WRITE_COMMENT: WriteCommentTask,
            TaskType.CLICK_LIKE: LikeTask,
            TaskType.WAIT: WaitTask,
            TaskType.SCROLL_READ: ScrollReadTask,
            TaskType.GOTO_URL: GoToUrlTask,
            # TaskType.CUSTOM은 LoopTask 등 특수 작업용
        }

        # 커스텀 작업 레지스트리
        self._custom_tasks: Dict[str, Type[BaseTask]] = {"LoopTask": LoopTask}

        # 생성된 작업 캐시 (선택적)
        self._task_cache: Dict[str, BaseTask] = {}

    def create_task(
        self, task_type: TaskType, name: Optional[str] = None, **parameters
    ) -> BaseTask:
        """
        작업 생성 및 의존성 주입

        Args:
            task_type: 작업 타입
            name: 작업 이름 (선택적)
            **parameters: 작업 파라미터

        Returns:
            생성된 작업 인스턴스
        """
        # 작업 클래스 찾기
        task_class = self._task_classes.get(task_type)
        if not task_class:
            raise ValueError(f"지원하지 않는 작업 타입: {task_type}")

        # 작업 인스턴스 생성
        task = task_class(name) if name else task_class()

        # 의존성 주입
        self._inject_dependencies(task)

        # 파라미터 설정
        if parameters:
            task.set_parameters(**parameters)

        # 작업별 추가 설정
        self._configure_task(task)

        self.logger.info(f"작업 생성됨: {task.name} (타입: {task_type.value})")

        return task

    def create_custom_task(
        self, task_class_name: str, name: Optional[str] = None, **parameters
    ) -> BaseTask:
        """
        커스텀 작업 생성

        Args:
            task_class_name: 커스텀 작업 클래스 이름
            name: 작업 이름
            **parameters: 작업 파라미터

        Returns:
            생성된 작업 인스턴스
        """
        task_class = self._custom_tasks.get(task_class_name)
        if not task_class:
            raise ValueError(f"등록되지 않은 커스텀 작업: {task_class_name}")

        task = task_class(name) if name else task_class()

        self._inject_dependencies(task)

        if parameters:
            task.set_parameters(**parameters)

        self._configure_task(task)

        self.logger.info(f"커스텀 작업 생성됨: {task.name}")

        return task

    def register_custom_task(self, task_class_name: str, task_class: Type[BaseTask]):
        """커스텀 작업 클래스 등록"""
        if not issubclass(task_class, BaseTask):
            raise ValueError(f"{task_class}는 BaseTask의 서브클래스여야 합니다.")

        self._custom_tasks[task_class_name] = task_class
        self.logger.info(f"커스텀 작업 등록됨: {task_class_name}")

    def _inject_dependencies(self, task: BaseTask) -> None:
        """작업에 의존성 주입"""
        # 기본 의존성
        if hasattr(task, "browser_manager"):
            task.browser_manager = self.browser_manager

        if hasattr(task, "config"):
            task.config = self.config

        if hasattr(task, "security_manager"):
            task.security_manager = self.security_manager

        if hasattr(task, "logger"):
            task.logger = self.logger.getChild(task.__class__.__name__)

    def _configure_task(self, task: BaseTask) -> None:
        """작업별 추가 설정"""
        # 로그인 작업
        if isinstance(task, LoginTask):
            self._configure_login_task(task)

        # 댓글 작업
        elif isinstance(task, WriteCommentTask):
            self._configure_comment_task(task)

        # 이웃 새글 확인 작업
        elif isinstance(task, CheckNewPostsTask):
            self._configure_check_posts_task(task)

    def _configure_login_task(self, task: LoginTask) -> None:
        """로그인 작업 설정"""
        # 현재 프로필에서 계정 정보 가져오기
        current_profile = self.config.get_current_profile_name()
        if current_profile:
            profile_data = self.config.get_profile(current_profile)
            if profile_data:
                # 비밀번호 복호화
                encrypted_pw = profile_data.get("naver_pw", "")
                if encrypted_pw and self.security_manager:
                    decrypted_pw = self.security_manager.decrypt_password(encrypted_pw)
                else:
                    decrypted_pw = ""

                # 파라미터 설정
                task.set_parameters(
                    user_id=profile_data.get("naver_id", ""), password=decrypted_pw
                )

    def _configure_comment_task(self, task: WriteCommentTask) -> None:
        """댓글 작업 설정"""
        # 설정에서 기본 댓글 스타일 가져오기
        comment_style = self.config.get("automation", "comment_style", "친근함")
        task.set_parameters(comment_style=comment_style)

        # AI API 키 설정 (있는 경우)
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if api_key:
            task.set_parameters(use_ai=True)
        else:
            self.logger.warning("AI API 키가 없습니다. 템플릿 기반 댓글을 사용합니다.")
            task.set_parameters(use_ai=False)

    def _configure_check_posts_task(self, task: CheckNewPostsTask) -> None:
        """이웃 새글 확인 작업 설정"""
        # 설정에서 필터 정보 가져오기
        daily_limit = self.config.get("automation", "daily_limit", 20)
        task.set_parameters(max_posts=daily_limit)

    # === 편의 메서드들 ===

    def create_login_task(
        self, user_id: Optional[str] = None, password: Optional[str] = None, **kwargs
    ) -> LoginTask:
        """로그인 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        if user_id:
            params["user_id"] = user_id
        if password:
            params["password"] = password

        return self.create_task(TaskType.LOGIN, **params)

    def create_comment_task(
        self, comment_text: Optional[str] = None, auto_generate: bool = True, **kwargs
    ) -> WriteCommentTask:
        """댓글 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        if comment_text:
            params["comment_text"] = comment_text
        params["auto_generate"] = auto_generate

        return self.create_task(TaskType.WRITE_COMMENT, **params)

    def create_wait_task(self, wait_time: float, **kwargs) -> WaitTask:
        """대기 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        params["wait_time"] = wait_time

        return self.create_task(TaskType.WAIT, **params)

    def create_like_task(self, post_url: Optional[str] = None, **kwargs) -> LikeTask:
        """좋아요 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        if post_url:
            params["post_url"] = post_url

        return self.create_task(TaskType.CLICK_LIKE, **params)

    def create_scroll_task(
        self, duration: int = 60, scroll_speed: str = "medium", **kwargs
    ) -> ScrollReadTask:
        """스크롤 읽기 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        params["duration"] = duration
        params["scroll_speed"] = scroll_speed

        return self.create_task(TaskType.SCROLL_READ, **params)

    def create_goto_url_task(self, url: str, **kwargs) -> GoToUrlTask:
        """URL 이동 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        params["url"] = url

        return self.create_task(TaskType.GOTO_URL, **params)

    def create_loop_task(
        self, sub_tasks: List[BaseTask], repeat_count: int = 1, **kwargs
    ) -> LoopTask:
        """반복 작업 생성 (편의 메서드)"""
        params = kwargs.copy()
        params["sub_tasks"] = sub_tasks
        params["repeat_count"] = repeat_count

        return self.create_custom_task("LoopTask", **params)

    def create_task_chain(self, task_configs: List[Dict[str, Any]]) -> List[BaseTask]:
        """
        작업 체인 생성

        Args:
            task_configs: 작업 설정 리스트

        Returns:
            생성된 작업 리스트
        """
        tasks = []

        for config in task_configs:
            task_type = config.get("type")
            if not task_type:
                self.logger.warning(f"작업 타입이 없습니다: {config}")
                continue

            # TaskType enum으로 변환
            if isinstance(task_type, str):
                try:
                    task_type = TaskType(task_type)
                except ValueError:
                    # 커스텀 작업일 수 있음
                    if task_type in self._custom_tasks:
                        task = self.create_custom_task(
                            task_type,
                            config.get("name"),
                            **config.get("parameters", {}),
                        )
                        tasks.append(task)
                        continue
                    else:
                        self.logger.error(f"알 수 없는 작업 타입: {task_type}")
                        continue

            # 작업 생성
            name = config.get("name")
            params = config.get("parameters", {})

            task = self.create_task(task_type, name, **params)

            # 의존성 설정
            dependencies = config.get("dependencies", [])
            if dependencies and hasattr(task, "dependencies"):
                task.dependencies = dependencies

            tasks.append(task)

        return tasks

    def create_from_json(self, json_data: Dict[str, Any]) -> List[BaseTask]:
        """JSON 데이터로부터 작업 생성"""
        task_configs = json_data.get("tasks", [])
        return self.create_task_chain(task_configs)

    def get_available_task_types(self) -> Dict[str, Type[BaseTask]]:
        """사용 가능한 모든 작업 타입 반환"""
        all_tasks = {}

        # 기본 작업들
        for task_type, task_class in self._task_classes.items():
            all_tasks[task_type.value] = task_class

        # 커스텀 작업들
        for task_name, task_class in self._custom_tasks.items():
            all_tasks[task_name] = task_class

        return all_tasks


# === 사용 예시 ===


def example_usage():
    """TaskFactory 사용 예시"""
    import os

    # 의존성 준비
    config = Config()
    security_manager = SecurityManager()
    browser_config = BrowserConfig(headless=False, timeout=20)
    browser_manager = BrowserManager(browser_config)

    # 팩토리 생성
    factory = TaskFactory(
        browser_manager=browser_manager,
        config=config,
        security_manager=security_manager,
    )

    # 개별 작업 생성
    login_task = factory.create_login_task()
    check_posts_task = factory.create_task(TaskType.CHECK_POSTS, max_posts=10)
    comment_task = factory.create_comment_task(auto_generate=True)
    like_task = factory.create_like_task()

    # 복잡한 작업 체인 생성
    task_chain = factory.create_task_chain(
        [
            {"type": TaskType.LOGIN.value, "name": "네이버 로그인", "parameters": {}},
            {
                "type": TaskType.WAIT.value,
                "name": "로그인 후 대기",
                "parameters": {"wait_time": 3},
            },
            {
                "type": TaskType.CHECK_POSTS.value,
                "name": "이웃 새글 확인",
                "parameters": {"max_posts": 20, "filter_keywords": ["여행", "맛집"]},
            },
            {
                "type": "LoopTask",  # 커스텀 작업
                "name": "포스트 처리 반복",
                "parameters": {
                    "repeat_count": 5,
                    "sub_tasks": [],  # 실제로는 하위 작업들을 넣어야 함
                },
            },
        ]
    )

    return task_chain


if __name__ == "__main__":
    # 테스트
    tasks = example_usage()
    for task in tasks:
        print(f"생성된 작업: {task}")
