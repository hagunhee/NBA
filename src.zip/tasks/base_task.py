"""
기본 작업 클래스 - 모든 작업의 베이스
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from enum import Enum
from datetime import datetime
import uuid


class TaskStatus(Enum):
    """작업 상태"""

    PENDING = "대기중"
    RUNNING = "실행중"
    COMPLETED = "완료"
    FAILED = "실패"
    CANCELLED = "취소됨"
    SKIPPED = "건너뜀"


class TaskType(Enum):
    """작업 타입"""

    LOGIN = "로그인"
    CHECK_POSTS = "이웃 새글 확인"
    WRITE_COMMENT = "댓글 작성"
    CLICK_LIKE = "좋아요 클릭"
    SCROLL_READ = "스크롤 읽기"
    WAIT = "대기"
    GOTO_URL = "URL 이동"
    CUSTOM = "사용자 정의"


class TaskResult:
    """작업 결과"""

    def __init__(self, success: bool, message: str = "", data: Any = None):
        self.success = success
        self.message = message
        self.data = data
        self.timestamp = datetime.now()


class BaseTask(ABC):
    """기본 작업 추상 클래스"""

    def __init__(self, task_type: TaskType, name: str = None, description: str = ""):
        self.id = str(uuid.uuid4())
        self.type = task_type
        self.name = name or task_type.value
        self.description = description
        self.status = TaskStatus.PENDING
        self.created_at = datetime.now()
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None
        self.result: Optional[TaskResult] = None
        self.parameters: Dict[str, Any] = {}
        self.retry_count = 0
        self.max_retries = 3
        self.dependencies: List[str] = []  # 의존하는 작업 ID 목록
        # 의존성 주입을 위한 속성

        self.browser_manager = None
        self.config = None
        self.security_manager = None
        self.logger = None

    @abstractmethod
    async def execute(
        self, browser_manager: Any, context: Dict[str, Any]
    ) -> TaskResult:
        """
        작업 실행 (비동기)

        Args:
            browser_manager: 브라우저 관리자
            context: 실행 컨텍스트 (이전 작업 결과 등)

        Returns:
            TaskResult: 작업 결과
        """
        pass

    @abstractmethod
    def validate_parameters(self) -> bool:
        """파라미터 검증"""
        pass

    @abstractmethod
    def get_estimated_duration(self) -> int:
        """예상 소요 시간 (초)"""
        pass

    def can_execute(self, completed_tasks: List[str]) -> bool:
        """
        작업 실행 가능 여부 확인

        Args:
            completed_tasks: 완료된 작업 ID 목록

        Returns:
            bool: 실행 가능 여부
        """
        # 모든 의존성이 완료되었는지 확인
        for dep_id in self.dependencies:
            if dep_id not in completed_tasks:
                return False
        return True

    def set_parameters(self, **kwargs):
        """파라미터 설정"""
        self.parameters.update(kwargs)

    def get_parameter(self, key: str, default: Any = None) -> Any:
        """파라미터 가져오기"""
        return self.parameters.get(key, default)

    def start(self):
        """작업 시작"""
        self.status = TaskStatus.RUNNING
        self.started_at = datetime.now()

    def complete(self, result: TaskResult):
        """작업 완료"""
        self.status = TaskStatus.COMPLETED if result.success else TaskStatus.FAILED
        self.completed_at = datetime.now()
        self.result = result

    def cancel(self):
        """작업 취소"""
        self.status = TaskStatus.CANCELLED
        self.completed_at = datetime.now()

    def skip(self):
        """작업 건너뛰기"""
        self.status = TaskStatus.SKIPPED
        self.completed_at = datetime.now()

    def reset(self):
        """작업 리셋"""
        self.status = TaskStatus.PENDING
        self.started_at = None
        self.completed_at = None
        self.result = None
        self.retry_count = 0

    def get_duration(self) -> Optional[int]:
        """실제 소요 시간 (초)"""
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds())
        return None

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환"""
        return {
            "id": self.id,
            "type": self.type.value,
            "name": self.name,
            "description": self.description,
            "status": self.status.value,
            "parameters": self.parameters,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": (
                self.completed_at.isoformat() if self.completed_at else None
            ),
            "duration": self.get_duration(),
            "result": (
                {"success": self.result.success, "message": self.result.message}
                if self.result
                else None
            ),
            "dependencies": self.dependencies,
        }

    def __repr__(self):
        return f"<{self.__class__.__name__}(id={self.id}, name={self.name}, status={self.status.value})>"
