"""
작업 스케줄러 - 작업들을 순차적/병렬적으로 실행
"""

import asyncio
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime
import logging
from collections import deque

from tasks.base_task import BaseTask, TaskStatus, TaskResult


class TaskScheduler:
    """작업 스케줄러"""

    def __init__(self, browser_manager: Any = None):
        self.browser_manager = browser_manager
        self.task_queue: deque[BaseTask] = deque()
        self.completed_tasks: Dict[str, BaseTask] = {}
        self.running_tasks: Dict[str, BaseTask] = {}
        self.context: Dict[str, Any] = {}  # 작업 간 공유 컨텍스트
        self.is_running = False
        self.is_paused = False
        self.logger = logging.getLogger(__name__)
        self.task_factory = None  # 팩토리 추가

        # 콜백 함수들
        self.on_task_start: Optional[Callable] = None
        self.on_task_complete: Optional[Callable] = None
        self.on_task_failed: Optional[Callable] = None
        self.on_scheduler_complete: Optional[Callable] = None

    def add_task(self, task: BaseTask) -> str:
        """작업 추가"""
        self.task_queue.append(task)
        self.logger.info(f"작업 추가됨: {task.name} (ID: {task.id})")
        return task.id

    def add_tasks(self, tasks: List[BaseTask]):
        """여러 작업 추가"""
        for task in tasks:
            self.add_task(task)

    def remove_task(self, task_id: str) -> bool:
        """작업 제거"""
        for i, task in enumerate(self.task_queue):
            if task.id == task_id:
                self.task_queue.remove(task)
                self.logger.info(f"작업 제거됨: {task.name} (ID: {task_id})")
                return True
        return False

    def clear_tasks(self):
        """모든 작업 제거"""
        self.task_queue.clear()
        self.completed_tasks.clear()
        self.running_tasks.clear()
        self.context.clear()
        self.logger.info("모든 작업이 제거되었습니다.")

    def get_task(self, task_id: str) -> Optional[BaseTask]:
        """작업 가져오기"""
        # 큐에서 찾기
        for task in self.task_queue:
            if task.id == task_id:
                return task

        # 실행 중인 작업에서 찾기
        if task_id in self.running_tasks:
            return self.running_tasks[task_id]

        # 완료된 작업에서 찾기
        if task_id in self.completed_tasks:
            return self.completed_tasks[task_id]

        return None

    def get_all_tasks(self) -> List[BaseTask]:
        """모든 작업 가져오기"""
        all_tasks = list(self.task_queue)
        all_tasks.extend(self.running_tasks.values())
        all_tasks.extend(self.completed_tasks.values())
        return all_tasks

    def get_pending_tasks(self) -> List[BaseTask]:
        """대기 중인 작업 목록"""
        return [task for task in self.task_queue if task.status == TaskStatus.PENDING]

    def get_executable_tasks(self) -> List[BaseTask]:
        """실행 가능한 작업 목록"""
        completed_ids = list(self.completed_tasks.keys())
        return [
            task
            for task in self.task_queue
            if task.status == TaskStatus.PENDING and task.can_execute(completed_ids)
        ]

    async def execute(self) -> Dict[str, Any]:
        """스케줄러 실행"""
        self.is_running = True
        self.is_paused = False
        start_time = datetime.now()
        total_tasks = len(self.task_queue)
        success_count = 0
        failed_count = 0

        self.logger.info(f"스케줄러 시작: 총 {total_tasks}개 작업")

        try:
            while self.task_queue and self.is_running:
                # 일시정지 확인
                while self.is_paused and self.is_running:
                    await asyncio.sleep(0.5)

                if not self.is_running:
                    break

                # 실행 가능한 작업 찾기
                executable_tasks = self.get_executable_tasks()

                if not executable_tasks:
                    # 실행 가능한 작업이 없으면 대기
                    await asyncio.sleep(1)
                    continue

                # 첫 번째 실행 가능한 작업 가져오기
                task = executable_tasks[0]
                self.task_queue.remove(task)

                # 작업 실행
                result = await self._execute_task(task)

                if result.success:
                    success_count += 1
                else:
                    failed_count += 1

                # 작업 간 대기
                await asyncio.sleep(1)

        except Exception as e:
            self.logger.error(f"스케줄러 실행 중 오류: {e}")

        finally:
            self.is_running = False
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()

            summary = {
                "total_tasks": total_tasks,
                "success_count": success_count,
                "failed_count": failed_count,
                "duration": duration,
                "completed_tasks": list(self.completed_tasks.values()),
            }

            self.logger.info(
                f"스케줄러 완료: 성공 {success_count}, 실패 {failed_count}, "
                f"소요시간 {duration:.1f}초"
            )

            if self.on_scheduler_complete:
                self.on_scheduler_complete(summary)

            return summary

    async def _execute_task(self, task: BaseTask) -> TaskResult:
        """개별 작업 실행 (수정)"""
        # 의존성 확인
        if not task.browser_manager and self.browser_manager:
            task.browser_manager = self.browser_manager

        self.logger.info(f"작업 시작: {task.name}")

        # 작업 시작 콜백
        if self.on_task_start:
            self.on_task_start(task)

        # 작업 시작
        task.start()
        self.running_tasks[task.id] = task

        try:
            # 작업 실행
            result = await task.execute(self.browser_manager, self.context)

            # 작업 완료
            task.complete(result)
            del self.running_tasks[task.id]
            self.completed_tasks[task.id] = task

            # 결과를 컨텍스트에 저장
            self.context[f"task_{task.id}_result"] = result.data

            # 작업 완료 콜백
            if result.success and self.on_task_complete:
                self.on_task_complete(task, result)
            elif not result.success and self.on_task_failed:
                self.on_task_failed(task, result)

            self.logger.info(
                f"작업 완료: {task.name} - "
                f"{'성공' if result.success else '실패'} ({result.message})"
            )

            return result

        except Exception as e:
            # 작업 실패 처리
            error_msg = f"작업 실행 중 오류: {str(e)}"
            self.logger.error(error_msg)

            result = TaskResult(success=False, message=error_msg)
            task.complete(result)

            if task.id in self.running_tasks:
                del self.running_tasks[task.id]
            self.completed_tasks[task.id] = task

            if self.on_task_failed:
                self.on_task_failed(task, result)

            return result

        except Exception as e:
            # 작업 실패 처리
            error_msg = f"작업 실행 중 오류: {str(e)}"
            self.logger.error(error_msg)

            result = TaskResult(success=False, message=error_msg)
            task.complete(result)

            if task.id in self.running_tasks:
                del self.running_tasks[task.id]
            self.completed_tasks[task.id] = task

            if self.on_task_failed:
                self.on_task_failed(task, result)

            return result

    def pause(self):
        """스케줄러 일시정지"""
        self.is_paused = True
        self.logger.info("스케줄러 일시정지")

    def resume(self):
        """스케줄러 재개"""
        self.is_paused = False
        self.logger.info("스케줄러 재개")

    def stop(self):
        """스케줄러 중지"""
        self.is_running = False
        self.logger.info("스케줄러 중지 요청")

    def get_progress(self) -> Dict[str, Any]:
        """진행 상황 가져오기"""
        total = len(self.get_all_tasks())
        completed = len(self.completed_tasks)
        running = len(self.running_tasks)
        pending = len(self.get_pending_tasks())

        return {
            "total": total,
            "completed": completed,
            "running": running,
            "pending": pending,
            "progress_percent": (completed / total * 100) if total > 0 else 0,
            "is_running": self.is_running,
            "is_paused": self.is_paused,
        }

    def move_task_up(self, task_id: str) -> bool:
        """작업 순서 위로 이동"""
        for i, task in enumerate(self.task_queue):
            if task.id == task_id and i > 0:
                self.task_queue[i], self.task_queue[i - 1] = (
                    self.task_queue[i - 1],
                    self.task_queue[i],
                )
                return True
        return False

    def move_task_down(self, task_id: str) -> bool:
        """작업 순서 아래로 이동"""
        for i, task in enumerate(self.task_queue):
            if task.id == task_id and i < len(self.task_queue) - 1:
                self.task_queue[i], self.task_queue[i + 1] = (
                    self.task_queue[i + 1],
                    self.task_queue[i],
                )
                return True
        return False
