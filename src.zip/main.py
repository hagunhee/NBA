#!/usr/bin/env python3
"""
네이버 블로그 자동화 프로그램
메인 진입점
"""
import sys
import os
import logging
from pathlib import Path
from typing import Optional
import argparse

# 프로젝트 경로 설정
project_root = Path(__file__).parent
src_path = project_root / "src"
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(src_path))

# 환경 변수 로드
from dotenv import load_dotenv

load_dotenv()

# 메인 애플리케이션 임포트 (v2만 사용)
from gui.main_window_v2 import MainApplication
from core.admin import AdminMenu
from utils.logger import Logger
from core.admin import AdminMenu


def check_requirements() -> bool:
    """필수 요구사항 확인"""
    errors = []

    # Python 버전 확인
    if sys.version_info < (3, 8):
        errors.append("Python 3.8 이상이 필요합니다.")

    # 필수 모듈 확인
    required_modules = [
        "selenium",
        "undetected_chromedriver",
        "firebase_admin",
        "cryptography",
        "requests",
        "psutil",
    ]

    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            errors.append(f"{module} 모듈이 설치되지 않았습니다.")

    # 에러가 있으면 출력
    if errors:
        print("=== 요구사항 확인 실패 ===")
        for error in errors:
            print(f"✗ {error}")
        print("\n다음 명령어로 필수 패키지를 설치하세요:")
        print("pip install -r requirements.txt")
        return False

    return True


def setup_environment():
    """환경 설정"""
    # 로그 디렉토리 생성
    log_dir = project_root / "logs"
    log_dir.mkdir(exist_ok=True)

    # 캐시 디렉토리 생성
    cache_dir = project_root / "cache"
    cache_dir.mkdir(exist_ok=True)

    # 데이터 디렉토리 생성
    data_dir = project_root / "data"
    data_dir.mkdir(exist_ok=True)


def parse_arguments():
    """명령행 인자 파싱"""
    parser = argparse.ArgumentParser(
        description="네이버 블로그 자동화 프로그램",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python main.py                  # 일반 GUI 모드
  python main.py --admin          # 관리자 모드
  python main.py --headless       # 헤드리스 모드
  python main.py --debug          # 디버그 모드
  python main.py --profile work   # 특정 프로필로 시작
        """,
    )

    parser.add_argument("--admin", action="store_true", help="관리자 모드로 실행")

    parser.add_argument(
        "--headless",
        action="store_true",
        help="헤드리스 모드로 실행 (브라우저 창 숨김)",
    )

    parser.add_argument(
        "--debug", action="store_true", help="디버그 모드 (상세 로그 출력)"
    )

    parser.add_argument("--profile", type=str, help="시작할 프로필 이름")

    parser.add_argument(
        "--config",
        type=str,
        default="config.json",
        help="설정 파일 경로 (기본값: config.json)",
    )

    parser.add_argument(
        "--no-update-check", action="store_true", help="자동 업데이트 확인 비활성화"
    )

    parser.add_argument("--version", action="version", version="%(prog)s 2.0.0")

    return parser.parse_args()


def run_admin_mode():
    """관리자 모드 실행"""
    print("=== 관리자 모드 ===")

    # 관리자 권한 확인 (Windows)
    if sys.platform == "win32":
        import ctypes

        if not ctypes.windll.shell32.IsUserAnAdmin():
            print("경고: 관리자 권한이 없습니다. 일부 기능이 제한될 수 있습니다.")

    admin = AdminMenu()
    admin.run()


def run_gui_mode(args):
    """GUI 모드 실행"""
    print("네이버 블로그 자동화 프로그램 시작...")

    try:
        # 메인 애플리케이션 생성
        app = MainApplication()

        # 명령행 옵션 적용
        if args.headless and hasattr(app, "toolbar"):
            app.toolbar.headless_var.set(True)

        if args.profile:
            # 특정 프로필로 시작
            app.toolbar.profile_var.set(args.profile)

        # 업데이트 확인
        if not args.no_update_check:
            # 백그라운드에서 업데이트 확인
            import threading

            threading.Thread(target=check_for_updates, args=(app,), daemon=True).start()

        # 애플리케이션 실행
        app.run()

    except Exception as e:
        import traceback

        print(f"프로그램 실행 중 오류 발생: {e}")
        print(traceback.format_exc())

        # GUI 오류 대화상자 표시 시도
        try:
            import tkinter as tk
            from tkinter import messagebox

            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "실행 오류", f"프로그램 실행 중 오류가 발생했습니다.\n\n{str(e)}"
            )
        except:
            pass


def check_for_updates(app):
    """업데이트 확인 (백그라운드)"""
    try:
        from core.updater import AutoUpdater

        updater = AutoUpdater(
            current_version="2.0.0",
            repo_owner="your-github-username",
            repo_name="naver-blog-automation",
        )

        update_info = updater.check_for_update()

        if update_info.get("available"):
            # UI 스레드에서 알림 표시
            app.root.after(1000, lambda: notify_update_available(app, update_info))

    except Exception as e:
        logging.debug(f"업데이트 확인 실패: {e}")


def notify_update_available(app, update_info):
    """업데이트 알림"""
    from tkinter import messagebox

    result = messagebox.askyesno(
        "업데이트 가능",
        f"새 버전 {update_info['version']}이 있습니다.\n\n"
        f"지금 업데이트하시겠습니까?",
    )

    if result:
        # 업데이트 다이얼로그 표시
        from core.updater import UpdateDialog

        dialog = UpdateDialog(app.root, app.updater)
        dialog.check_and_prompt()


def main():
    """메인 함수"""
    # 인자 파싱
    args = parse_arguments()

    # 로깅 설정
    log_level = logging.DEBUG if args.debug else logging.INFO
    setup_logging(log_level)

    # 환경 설정
    setup_environment()

    # 요구사항 확인
    if not check_requirements():
        sys.exit(1)

    # API 키 확인
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("경고: ANTHROPIC_API_KEY가 설정되지 않았습니다.")
        print("AI 기반 댓글 생성 기능이 제한될 수 있습니다.")

    # 실행 모드 선택
    if args.admin:
        run_admin_mode()
    else:
        run_gui_mode(args)


def setup_logging(level=logging.INFO):
    """로깅 설정"""
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # 콘솔 핸들러
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(logging.Formatter(log_format))

    # 파일 핸들러
    from datetime import datetime

    log_file = project_root / "logs" / f"app_{datetime.now().strftime('%Y%m%d')}.log"
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(log_format))

    # 루트 로거 설정
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)

    # 외부 라이브러리 로그 레벨 조정
    logging.getLogger("selenium").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("firebase_admin").setLevel(logging.WARNING)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n프로그램이 사용자에 의해 중단되었습니다.")
        sys.exit(0)
    except Exception as e:
        print(f"\n예상치 못한 오류가 발생했습니다: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)
