import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import firebase_admin
from firebase_admin import credentials, firestore
import hashlib
import platform
import uuid
import psutil
import json
import os
from datetime import datetime, timedelta
import threading
import requests


class FirestoreSecurityManager:
    """Firestore 기반 보안 및 라이선스 관리"""

    def __init__(self, firebase_config_path="serviceAccountKey.json"):
        self.db = None
        self.firebase_config_path = firebase_config_path
        self.init_firebase()

    def init_firebase(self):
        """Firebase 초기화"""
        try:
            # Firebase 앱이 이미 초기화되었는지 확인
            if not firebase_admin._apps:
                # 서비스 계정 키 파일로 초기화
                if os.path.exists(self.firebase_config_path):
                    cred = credentials.Certificate(self.firebase_config_path)
                    firebase_admin.initialize_app(cred)
                else:
                    print(
                        f"Firebase 설정 파일을 찾을 수 없습니다: {self.firebase_config_path}"
                    )
                    return False

            self.db = firestore.client()
            print("Firebase 연결 성공")
            return True

        except Exception as e:
            print(f"Firebase 초기화 실패: {e}")
            return False

    def get_hardware_id(self):
        """하드웨어 고유 ID 생성 (WMI 대신 안전한 방법 사용)"""
        try:
            # 다양한 시스템 정보 수집
            system_info = []

            # 플랫폼 정보
            system_info.append(platform.machine())
            system_info.append(platform.processor())
            system_info.append(platform.system())

            # MAC 주소 (네트워크 인터페이스)
            try:
                mac = hex(uuid.getnode())
                system_info.append(mac)
            except:
                pass

            # CPU 정보
            try:
                import cpuinfo

                cpu_info = cpuinfo.get_cpu_info()
                system_info.append(cpu_info.get("brand_raw", ""))
            except:
                pass

            # 메모리 정보
            try:
                memory = psutil.virtual_memory()
                system_info.append(str(memory.total))
            except:
                pass

            # 디스크 정보
            try:
                disk_usage = psutil.disk_usage("/")
                system_info.append(str(disk_usage.total))
            except:
                pass

            # Windows 특정 정보 (WMI 없이)
            if platform.system() == "Windows":
                try:
                    import subprocess

                    # Windows 시스템 정보
                    result = subprocess.run(
                        ["wmic", "csproduct", "get", "uuid"],
                        capture_output=True,
                        text=True,
                    )
                    if result.returncode == 0:
                        uuid_info = result.stdout.strip().split("\n")
                        if len(uuid_info) > 1:
                            system_info.append(uuid_info[1].strip())
                except:
                    pass

            # 모든 정보를 결합하여 해시 생성
            combined_info = "".join(system_info)
            hardware_id = hashlib.sha256(combined_info.encode()).hexdigest()

            return hardware_id

        except Exception as e:
            print(f"하드웨어 ID 생성 실패: {e}")
            # 기본 fallback
            fallback_info = (
                f"{platform.machine()}-{platform.system()}-{hex(uuid.getnode())}"
            )
            return hashlib.md5(fallback_info.encode()).hexdigest()

    def verify_license_online(self, license_key):
        """온라인으로 라이선스 검증"""
        if not self.db:
            return False, "Firebase 연결 실패"

        try:
            # Firestore에서 라이선스 정보 조회
            license_ref = self.db.collection("licenses").document(license_key)
            license_doc = license_ref.get()

            if not license_doc.exists:
                return False, "존재하지 않는 라이선스입니다."

            license_data = license_doc.to_dict()

            # 활성화 상태 확인
            if not license_data.get("active", False):
                return False, "비활성화된 라이선스입니다."

            # 만료일 확인
            expire_date = license_data.get("expire_date")
            if expire_date and isinstance(expire_date, str):
                expire_datetime = datetime.fromisoformat(expire_date)
                if datetime.now() > expire_datetime:
                    return False, "만료된 라이선스입니다."

            # 하드웨어 ID 확인 및 등록
            current_hardware_id = self.get_hardware_id()
            stored_hardware_id = license_data.get("hardware_id")

            if not stored_hardware_id:
                # 첫 번째 사용 - 하드웨어 ID 등록
                license_ref.update(
                    {
                        "hardware_id": current_hardware_id,
                        "first_used": datetime.now().isoformat(),
                        "last_used": datetime.now().isoformat(),
                    }
                )
                print("하드웨어 ID가 등록되었습니다.")
            elif stored_hardware_id != current_hardware_id:
                return False, "다른 컴퓨터에서는 사용할 수 없는 라이선스입니다."
            else:
                # 마지막 사용 시간 업데이트
                license_ref.update({"last_used": datetime.now().isoformat()})

            return True, license_data

        except Exception as e:
            return False, f"라이선스 검증 중 오류: {str(e)}"

    def get_license_info(self, license_key):
        """라이선스 정보 조회"""
        if not self.db:
            return None

        try:
            license_ref = self.db.collection("licenses").document(license_key)
            license_doc = license_ref.get()

            if license_doc.exists:
                return license_doc.to_dict()
            return None

        except Exception as e:
            print(f"라이선스 정보 조회 실패: {e}")
            return None


class AutoUpdater:
    """자동 업데이트 관리"""

    def __init__(self, current_version, repo_owner, repo_name):
        self.current_version = current_version
        self.github_api = (
            f"https://api.github.com/repos/{repo_owner}/{repo_name}/releases/latest"
        )

    def check_for_update(self):
        """업데이트 확인"""
        try:
            response = requests.get(self.github_api, timeout=10)
            if response.status_code == 200:
                latest_release = response.json()
                latest_version = latest_release["tag_name"]

                if self.version_compare(latest_version, self.current_version):
                    for asset in latest_release["assets"]:
                        if asset["name"].endswith(".exe"):
                            return {
                                "available": True,
                                "version": latest_version,
                                "download_url": asset["browser_download_url"],
                                "changelog": latest_release.get("body", ""),
                            }
            return {"available": False}
        except Exception as e:
            print(f"업데이트 확인 실패: {e}")
            return {"available": False}

    def version_compare(self, v1, v2):
        """버전 비교"""

        def normalize(v):
            return [int(x) for x in v.replace("v", "").split(".")]

        return normalize(v1) > normalize(v2)


class BlogManagerGUI:
    """메인 GUI 클래스"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("네이버 블로그 자동화 프로그램 v1.0.0")
        self.root.geometry("900x700")
        self.root.resizable(True, True)

        # 보안 매니저 초기화
        self.security_manager = FirestoreSecurityManager()
        self.is_licensed = False
        self.license_info = None
        self.current_license_key = None

        # 업데이터 초기화
        self.updater = AutoUpdater("v1.0.0", "your_username", "your_repo")

        self.setup_gui()
        self.check_saved_license()

    def setup_gui(self):
        """GUI 구성"""
        # 스타일 설정
        style = ttk.Style()
        style.theme_use("clam")

        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="15")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 제목
        title_label = ttk.Label(
            main_frame, text="네이버 블로그 자동화 프로그램", font=("Arial", 16, "bold")
        )
        title_label.pack(pady=(0, 20))

        # 라이선스 프레임
        license_frame = ttk.LabelFrame(main_frame, text="라이선스 인증", padding="15")
        license_frame.pack(fill=tk.X, pady=(0, 15))

        # 라이선스 키 입력
        license_input_frame = ttk.Frame(license_frame)
        license_input_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(license_input_frame, text="라이선스 키:").pack(anchor=tk.W)

        license_entry_frame = ttk.Frame(license_input_frame)
        license_entry_frame.pack(fill=tk.X, pady=(5, 0))

        self.license_entry = ttk.Entry(license_entry_frame, font=("Consolas", 10))
        self.license_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))

        self.verify_btn = ttk.Button(
            license_entry_frame, text="인증", command=self.verify_license
        )
        self.verify_btn.pack(side=tk.RIGHT)

        # 라이선스 상태
        self.license_status = ttk.Label(
            license_frame, text="라이선스를 입력하고 인증해주세요.", foreground="gray"
        )
        self.license_status.pack(anchor=tk.W, pady=(10, 0))

        # 하드웨어 ID 표시
        hardware_id = self.security_manager.get_hardware_id()
        hardware_frame = ttk.Frame(license_frame)
        hardware_frame.pack(fill=tk.X, pady=(10, 0))

        ttk.Label(hardware_frame, text="하드웨어 ID:", font=("Arial", 8)).pack(
            anchor=tk.W
        )
        hardware_id_label = ttk.Label(
            hardware_frame,
            text=hardware_id[:16] + "...",
            font=("Consolas", 8),
            foreground="gray",
        )
        hardware_id_label.pack(anchor=tk.W)

        # 네이버 로그인 프레임
        self.login_frame = ttk.LabelFrame(main_frame, text="네이버 계정", padding="15")
        self.login_frame.pack(fill=tk.X, pady=(0, 15))

        login_grid = ttk.Frame(self.login_frame)
        login_grid.pack(fill=tk.X)

        ttk.Label(login_grid, text="아이디:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.naver_id_entry = ttk.Entry(login_grid, width=25)
        self.naver_id_entry.grid(row=0, column=1, padx=(10, 20), pady=5, sticky=tk.W)

        ttk.Label(login_grid, text="비밀번호:").grid(
            row=1, column=0, sticky=tk.W, pady=5
        )
        self.naver_pw_entry = ttk.Entry(login_grid, width=25, show="*")
        self.naver_pw_entry.grid(row=1, column=1, padx=(10, 20), pady=5, sticky=tk.W)

        self.login_btn = ttk.Button(
            login_grid, text="로그인 테스트", command=self.test_naver_login
        )
        self.login_btn.grid(row=0, column=2, rowspan=2, padx=(20, 0), pady=5)

        self.login_status = ttk.Label(self.login_frame, text="", font=("Arial", 9))
        self.login_status.pack(anchor=tk.W, pady=(10, 0))

        # Claude API 프레임
        self.api_frame = ttk.LabelFrame(
            main_frame, text="Claude API 설정", padding="15"
        )
        self.api_frame.pack(fill=tk.X, pady=(0, 15))

        api_input_frame = ttk.Frame(self.api_frame)
        api_input_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(api_input_frame, text="Claude API 키:").pack(anchor=tk.W)

        api_entry_frame = ttk.Frame(api_input_frame)
        api_entry_frame.pack(fill=tk.X, pady=(5, 0))

        self.claude_api_entry = ttk.Entry(api_entry_frame, show="*")
        self.claude_api_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))

        self.api_test_btn = ttk.Button(
            api_entry_frame, text="연결 테스트", command=self.test_claude_api
        )
        self.api_test_btn.pack(side=tk.RIGHT)

        # 자동화 설정 프레임
        self.automation_frame = ttk.LabelFrame(
            main_frame, text="자동화 설정", padding="15"
        )
        self.automation_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))

        # 블로그 URL 입력
        url_frame = ttk.Frame(self.automation_frame)
        url_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(url_frame, text="대상 블로그 URL:").pack(anchor=tk.W)
        self.blog_url_entry = ttk.Entry(url_frame, width=60)
        self.blog_url_entry.pack(fill=tk.X, pady=(5, 0))

        # 설정 옵션들
        settings_frame = ttk.Frame(self.automation_frame)
        settings_frame.pack(fill=tk.X, pady=(10, 0))

        # 댓글 스타일
        style_frame = ttk.Frame(settings_frame)
        style_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(style_frame, text="댓글 스타일:").pack(side=tk.LEFT)
        self.comment_style = ttk.Combobox(
            style_frame,
            values=["친근함", "전문적", "캐주얼", "응원"],
            state="readonly",
            width=15,
        )
        self.comment_style.pack(side=tk.LEFT, padx=(10, 20))
        self.comment_style.set("친근함")

        # 댓글 개수
        ttk.Label(style_frame, text="댓글 개수:").pack(side=tk.LEFT)
        self.comment_count = ttk.Spinbox(style_frame, from_=1, to=10, width=10, value=3)
        self.comment_count.pack(side=tk.LEFT, padx=(10, 0))

        # 실행 버튼들
        button_frame = ttk.Frame(self.automation_frame)
        button_frame.pack(fill=tk.X, pady=(20, 0))

        self.start_btn = ttk.Button(
            button_frame,
            text="자동 댓글 시작",
            command=self.start_automation,
            style="Accent.TButton",
        )
        self.start_btn.pack(side=tk.LEFT, padx=(0, 10))

        self.stop_btn = ttk.Button(
            button_frame, text="중지", command=self.stop_automation, state=tk.DISABLED
        )
        self.stop_btn.pack(side=tk.LEFT, padx=(0, 10))

        # 업데이트 버튼
        self.update_btn = ttk.Button(
            button_frame, text="업데이트 확인", command=self.check_update
        )
        self.update_btn.pack(side=tk.RIGHT)

        # 진행 상황
        progress_frame = ttk.Frame(self.automation_frame)
        progress_frame.pack(fill=tk.X, pady=(20, 10))

        ttk.Label(progress_frame, text="진행 상황:").pack(anchor=tk.W)
        self.progress = ttk.Progressbar(progress_frame, mode="indeterminate")
        self.progress.pack(fill=tk.X, pady=(5, 0))

        # 로그 출력 영역
        log_frame = ttk.LabelFrame(main_frame, text="실행 로그", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.log_text = scrolledtext.ScrolledText(
            log_frame, height=12, font=("Consolas", 9)
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # 초기 상태 설정
        self.set_gui_state(False)

        # 시작 메시지
        self.log_message("프로그램이 시작되었습니다.")
        self.log_message(f"하드웨어 ID: {hardware_id}")

    def set_gui_state(self, enabled):
        """GUI 활성화/비활성화"""
        state = tk.NORMAL if enabled else tk.DISABLED

        widgets = [
            self.naver_id_entry,
            self.naver_pw_entry,
            self.login_btn,
            self.claude_api_entry,
            self.api_test_btn,
            self.blog_url_entry,
            self.comment_style,
            self.comment_count,
            self.start_btn,
        ]

        for widget in widgets:
            widget.config(state=state)

    def log_message(self, message):
        """로그 메시지 출력"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update()

    def check_saved_license(self):
        """저장된 라이선스 확인"""
        try:
            if os.path.exists("license.dat"):
                with open("license.dat", "r") as f:
                    license_key = f.read().strip()
                    if license_key:
                        self.license_entry.insert(0, license_key)
                        self.log_message("저장된 라이선스를 불러왔습니다.")
        except Exception as e:
            self.log_message(f"라이선스 불러오기 실패: {e}")

    def verify_license(self):
        """라이선스 검증"""
        license_key = self.license_entry.get().strip()
        if not license_key:
            self.license_status.config(
                text="라이선스 키를 입력해주세요.", foreground="red"
            )
            return

        self.log_message("라이선스 검증 중...")
        self.verify_btn.config(state=tk.DISABLED, text="검증 중...")

        # 별도 스레드에서 검증
        threading.Thread(
            target=self._verify_license_thread, args=(license_key,), daemon=True
        ).start()

    def _verify_license_thread(self, license_key):
        """라이선스 검증 스레드"""
        try:
            success, result = self.security_manager.verify_license_online(license_key)

            # UI 업데이트는 메인 스레드에서
            self.root.after(
                0, self._handle_license_result, success, result, license_key
            )

        except Exception as e:
            self.root.after(
                0, self._handle_license_result, False, f"검증 중 오류: {e}", license_key
            )

    def _handle_license_result(self, success, result, license_key):
        """라이선스 검증 결과 처리"""
        self.verify_btn.config(state=tk.NORMAL, text="인증")

        if success:
            self.is_licensed = True
            self.license_info = result
            self.current_license_key = license_key

            # 만료일 계산
            expire_date_str = result.get("expire_date")
            if expire_date_str:
                expire_date = datetime.fromisoformat(expire_date_str)
                days_left = (expire_date - datetime.now()).days
                expire_text = f"({days_left}일 남음)" if days_left > 0 else "(만료됨)"
            else:
                expire_text = "(무제한)"

            customer_id = result.get("customer_id", "Unknown")

            self.license_status.config(
                text=f"✓ 라이선스 인증 완료 {expire_text} - {customer_id}",
                foreground="green",
            )

            self.set_gui_state(True)
            self.log_message(f"라이선스 인증 성공: {customer_id}")

            # 라이선스 키 저장
            try:
                with open("license.dat", "w") as f:
                    f.write(license_key)
            except:
                pass

        else:
            self.is_licensed = False
            self.license_status.config(text=f"✗ {result}", foreground="red")
            self.set_gui_state(False)
            self.log_message(f"라이선스 인증 실패: {result}")

    def test_naver_login(self):
        """네이버 로그인 테스트"""
        if not self.is_licensed:
            messagebox.showerror("오류", "먼저 라이선스를 인증해주세요.")
            return

        user_id = self.naver_id_entry.get().strip()
        password = self.naver_pw_entry.get().strip()

        if not user_id or not password:
            messagebox.showerror("오류", "아이디와 비밀번호를 입력해주세요.")
            return

        self.login_status.config(text="로그인 테스트 중...", foreground="orange")
        self.log_message("네이버 로그인 테스트 시작...")

        # 실제 로그인 테스트 로직은 여기에 구현
        # 현재는 시뮬레이션
        self.root.after(2000, self._simulate_login_test)

    def _simulate_login_test(self):
        """로그인 테스트 시뮬레이션"""
        self.login_status.config(text="✓ 로그인 테스트 성공", foreground="green")
        self.log_message("네이버 로그인 테스트 완료")

    def test_claude_api(self):
        """Claude API 연결 테스트"""
        api_key = self.claude_api_entry.get().strip()
        if not api_key:
            messagebox.showerror("오류", "Claude API 키를 입력해주세요.")
            return

        self.log_message("Claude API 연결 테스트 중...")
        # 실제 API 테스트 로직 구현
        messagebox.showinfo("성공", "Claude API 연결 테스트 성공!")
        self.log_message("Claude API 연결 성공")

    def start_automation(self):
        """자동화 시작"""
        if not self.is_licensed:
            messagebox.showerror("오류", "라이선스를 인증해주세요.")
            return

        blog_url = self.blog_url_entry.get().strip()
        if not blog_url:
            messagebox.showerror("오류", "블로그 URL을 입력해주세요.")
            return

        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress.start()

        self.log_message("자동 댓글 작업 시작...")

        # 실제 자동화 로직은 별도 스레드에서 실행
        threading.Thread(target=self._automation_thread, daemon=True).start()

    def _automation_thread(self):
        """자동화 실행 스레드"""
        import time

        try:
            comment_count = int(self.comment_count.get())

            for i in range(comment_count):
                if hasattr(self, "_stop_automation") and self._stop_automation:
                    break

                self.root.after(
                    0, self.log_message, f"댓글 {i+1}/{comment_count} 작성 중..."
                )
                time.sleep(2)  # 시뮬레이션

            self.root.after(0, self.log_message, "자동 댓글 작업 완료!")

        except Exception as e:
            self.root.after(0, self.log_message, f"오류 발생: {e}")

        finally:
            self.root.after(0, self._reset_automation_ui)

    def _reset_automation_ui(self):
        """자동화 UI 리셋"""
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress.stop()
        self._stop_automation = False

    def stop_automation(self):
        """자동화 중지"""
        self._stop_automation = True
        self.log_message("자동화 중지 요청...")

    def check_update(self):
        """업데이트 확인"""
        self.log_message("업데이트 확인 중...")

        update_info = self.updater.check_for_update()

        if update_info.get("available"):
            result = messagebox.askyesno(
                "업데이트 알림",
                f"새 버전 {update_info['version']}이(가) 있습니다.\n"
                f"현재 버전: v1.0.0\n\n업데이트하시겠습니까?",
            )
            if result:
                self.log_message("업데이트를 준비합니다...")
                # 실제 업데이트 로직 구현
        else:
            messagebox.showinfo("업데이트", "현재 최신 버전을 사용하고 있습니다.")
            self.log_message("최신 버전 사용 중")

    def on_closing(self):
        """프로그램 종료 시 처리"""
        if hasattr(self, "_stop_automation"):
            self._stop_automation = True

        self.root.destroy()

    def run(self):
        """프로그램 실행"""
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()


# Firestore 라이선스 생성 도구 (관리자용)
def create_license_in_firestore(license_key, customer_id, days=30, features=None):
    """Firestore에 새 라이선스 생성"""
    if features is None:
        features = ["blog_management", "auto_comment"]

    try:
        # Firebase 초기화
        if not firebase_admin._apps:
            cred = credentials.Certificate("serviceAccountKey.json")
            firebase_admin.initialize_app(cred)

        db = firestore.client()

        # 라이선스 데이터
        expire_date = datetime.now() + timedelta(days=days) if days > 0 else None

        license_data = {
            "customer_id": customer_id,
            "active": True,
            "created_date": datetime.now().isoformat(),
            "expire_date": expire_date.isoformat() if expire_date else None,
            "features": features,
            "max_devices": 1,
            "hardware_id": None,  # 첫 사용 시 등록됨
            "first_used": None,
            "last_used": None,
            "usage_count": 0,
        }

        # Firestore에 저장
        db.collection("licenses").document(license_key).set(license_data)

        print(f"✓ 라이선스 생성 완료")
        print(f"  - 라이선스 키: {license_key}")
        print(f"  - 고객 ID: {customer_id}")
        print(f"  - 유효 기간: {days}일" if days > 0 else "  - 유효 기간: 무제한")
        print(f"  - 기능: {', '.join(features)}")

        return True

    except Exception as e:
        print(f"라이선스 생성 실패: {e}")
        return False


def list_licenses():
    """모든 라이선스 목록 조회"""
    try:
        if not firebase_admin._apps:
            cred = credentials.Certificate("serviceAccountKey.json")
            firebase_admin.initialize_app(cred)

        db = firestore.client()
        licenses = db.collection("licenses").get()

        print("=" * 80)
        print("라이선스 목록")
        print("=" * 80)

        for license_doc in licenses:
            license_key = license_doc.id
            data = license_doc.to_dict()

            status = "활성" if data.get("active") else "비활성"
            customer_id = data.get("customer_id", "Unknown")
            expire_date = data.get("expire_date")
            hardware_id = data.get("hardware_id")

            if expire_date:
                expire_dt = datetime.fromisoformat(expire_date)
                days_left = (expire_dt - datetime.now()).days
                expire_text = f"{days_left}일 남음" if days_left > 0 else "만료됨"
            else:
                expire_text = "무제한"

            print(f"키: {license_key}")
            print(f"  고객: {customer_id}")
            print(f"  상태: {status}")
            print(f"  만료: {expire_text}")
            print(f"  하드웨어: {'등록됨' if hardware_id else '미등록'}")
            print(f"  사용횟수: {data.get('usage_count', 0)}")
            print("-" * 40)

    except Exception as e:
        print(f"라이선스 목록 조회 실패: {e}")


def deactivate_license(license_key):
    """라이선스 비활성화"""
    try:
        if not firebase_admin._apps:
            cred = credentials.Certificate("firebase-config.json")
            firebase_admin.initialize_app(cred)

        db = firestore.client()

        license_ref = db.collection("licenses").document(license_key)
        license_doc = license_ref.get()

        if not license_doc.exists:
            print(f"라이선스를 찾을 수 없습니다: {license_key}")
            return False

        license_ref.update(
            {"active": False, "deactivated_date": datetime.now().isoformat()}
        )

        print(f"✓ 라이선스 비활성화 완료: {license_key}")
        return True

    except Exception as e:
        print(f"라이선스 비활성화 실패: {e}")
        return False


class NaverBlogAutomation:
    """네이버 블로그 자동화 실제 구현"""

    def __init__(self, headless=True):
        self.driver = None
        self.headless = headless
        self.is_logged_in = False

    def setup_driver(self):
        """Chrome 드라이버 설정"""
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options

        options = Options()
        if self.headless:
            options.add_argument("--headless")

        # 기본 옵션들
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)

        # User-Agent 설정
        options.add_argument(
            "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )

        try:
            self.driver = webdriver.Chrome(options=options)
            self.driver.execute_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
            )
            return True
        except Exception as e:
            print(f"드라이버 설정 실패: {e}")
            return False

    def login_naver(self, user_id, password):
        """네이버 로그인"""
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        import time

        try:
            self.driver.get("https://nid.naver.com/nidlogin.login")
            time.sleep(2)

            # 로그인 폼이 로드될 때까지 대기
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "id"))
            )

            # JavaScript로 입력 (Selenium 탐지 우회)
            self.driver.execute_script(
                f"document.getElementById('id').value = '{user_id}';"
            )
            time.sleep(1)
            self.driver.execute_script(
                f"document.getElementById('pw').value = '{password}';"
            )
            time.sleep(1)

            # 로그인 버튼 클릭
            login_btn = self.driver.find_element(By.ID, "log.login")
            self.driver.execute_script("arguments[0].click();", login_btn)

            # 로그인 결과 대기
            time.sleep(5)

            # 로그인 성공 여부 확인
            current_url = self.driver.current_url

            if "nid.naver.com" not in current_url or "naver.com" in current_url:
                self.is_logged_in = True
                return True, "로그인 성공"
            elif "captcha" in current_url:
                return False, "캡차 인증이 필요합니다"
            else:
                return False, "로그인 실패 - 아이디/비밀번호를 확인해주세요"

        except Exception as e:
            return False, f"로그인 중 오류: {str(e)}"

    def close(self):
        """드라이버 종료"""
        if self.driver:
            self.driver.quit()


class ClaudeCommentGenerator:
    """Claude API를 이용한 댓글 생성"""

    def __init__(self, api_key):
        try:
            import anthropic

            self.client = anthropic.Anthropic(api_key=api_key)
            self.api_key = api_key
        except ImportError:
            raise ImportError(
                "anthropic 패키지가 설치되지 않았습니다. 'pip install anthropic'으로 설치해주세요."
            )

    def generate_comment(self, post_title, post_content, style="친근함"):
        """포스트 내용을 바탕으로 자연스러운 댓글 생성"""

        style_map = {
            "친근함": "친근하고 따뜻한 톤으로",
            "전문적": "전문적이고 정중한 톤으로",
            "캐주얼": "편안하고 자연스러운 톤으로",
            "응원": "격려하고 응원하는 톤으로",
        }

        tone = style_map.get(style, "자연스러운 톤으로")

        prompt = f"""
다음 블로그 포스트에 대해 {tone} 댓글을 작성해주세요.

포스트 제목: {post_title}
포스트 내용 일부: {post_content[:300]}

댓글 작성 가이드라인:
1. 1-2문장으로 간결하게 작성
2. 포스트 내용과 관련된 구체적인 반응
3. 자연스럽고 진정성 있게
4. 광고나 홍보성 내용 금지
5. 이모지 1-2개 정도 사용 가능
6. 한국어로 작성

댓글만 작성해주세요:"""

        try:
            response = self.client.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=100,
                messages=[{"role": "user", "content": prompt}],
            )

            comment = response.content[0].text.strip()
            # 댓글이 너무 길면 자르기
            if len(comment) > 100:
                comment = comment[:97] + "..."

            return comment

        except Exception as e:
            print(f"댓글 생성 실패: {e}")
            # 기본 댓글 반환
            fallback_comments = [
                "좋은 글 잘 읽었습니다! 😊",
                "유익한 정보 감사해요 👍",
                "정말 도움이 되는 내용이네요!",
                "좋은 글 공유해주셔서 감사합니다 ✨",
            ]
            import random

            return random.choice(fallback_comments)


# 관리자 도구 실행 함수들
def admin_create_license():
    """관리자용 라이선스 생성"""
    print("=" * 50)
    print("라이선스 생성 도구")
    print("=" * 50)

    license_key = input("라이선스 키 (비워두면 자동 생성): ").strip()
    if not license_key:
        import secrets

        license_key = secrets.token_urlsafe(16)
        print(f"자동 생성된 라이선스 키: {license_key}")

    customer_id = input("고객 ID: ").strip()
    if not customer_id:
        print("고객 ID는 필수입니다.")
        return

    try:
        days = int(input("유효 기간 (일, 0=무제한): ") or "30")
    except ValueError:
        days = 30

    features_input = input("기능 (쉼표로 구분, 비워두면 기본값): ").strip()
    if features_input:
        features = [f.strip() for f in features_input.split(",")]
    else:
        features = ["blog_management", "auto_comment"]

    success = create_license_in_firestore(license_key, customer_id, days, features)

    if success:
        print("\n라이선스가 성공적으로 생성되었습니다!")
        print("고객에게 다음 라이선스 키를 전달해주세요:")
        print(f">>> {license_key} <<<")


def admin_menu():
    """관리자 메뉴"""
    while True:
        print("\n" + "=" * 50)
        print("관리자 도구")
        print("=" * 50)
        print("1. 라이선스 생성")
        print("2. 라이선스 목록 조회")
        print("3. 라이선스 비활성화")
        print("4. 프로그램 실행")
        print("0. 종료")
        print("-" * 50)

        choice = input("선택: ").strip()

        if choice == "1":
            admin_create_license()
        elif choice == "2":
            list_licenses()
        elif choice == "3":
            license_key = input("비활성화할 라이선스 키: ").strip()
            if license_key:
                deactivate_license(license_key)
        elif choice == "4":
            app = BlogManagerGUI()
            app.run()
            break
        elif choice == "0":
            break
        else:
            print("잘못된 선택입니다.")


# 메인 실행
if __name__ == "__main__":
    import sys

    # 명령행 인수로 관리자 모드 실행
    if len(sys.argv) > 1 and sys.argv[1] == "--admin":
        admin_menu()
    else:
        # 일반 사용자 모드
        app = BlogManagerGUI()
        app.run()
