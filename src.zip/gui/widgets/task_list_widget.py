"""
작업 목록 위젯 - 사용 가능한 작업들을 표시
"""

import tkinter as tk
from tkinter import ttk
from typing import List, Dict, Any, Callable, Optional

from tasks.base_task import TaskType
from tasks.login_task import LoginTask
from tasks.check_posts_task import CheckNewPostsTask
from tasks.comment_task import WriteCommentTask
from tasks.utility_task import WaitTask, ScrollReadTask, GoToUrlTask, LikeTask


class TaskListWidget(ttk.Frame):
    """작업 목록 위젯"""

    def __init__(self, parent, on_task_double_click: Optional[Callable] = None):
        """
        Args:
            parent: 부모 위젯
            on_task_double_click: 작업 더블클릭 시 호출될 콜백
        """
        super().__init__(parent)

        self.on_task_double_click = on_task_double_click
        self.available_tasks = self._get_available_tasks()
        self.filtered_tasks = self.available_tasks.copy()

        self._setup_ui()
        self._load_tasks()

    def _setup_ui(self):
        """UI 구성"""
        # 제목
        title_label = ttk.Label(self, text="📋 작업 목록", font=("Arial", 11, "bold"))
        title_label.pack(anchor=tk.W, pady=(0, 10))

        # 검색 프레임
        search_frame = ttk.Frame(self)
        search_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(search_frame, text="검색:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(
            search_frame, textvariable=self.search_var, width=25
        )
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        self.search_var.trace("w", self._on_search_changed)

        # 카테고리 필터
        filter_frame = ttk.Frame(self)
        filter_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(filter_frame, text="카테고리:").pack(side=tk.LEFT)
        self.category_var = tk.StringVar(value="전체")
        self.category_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.category_var,
            values=["전체", "기본", "포스트", "유틸리티"],
            state="readonly",
            width=15,
        )
        self.category_combo.pack(side=tk.LEFT, padx=(5, 0))
        self.category_combo.bind("<<ComboboxSelected>>", self._on_category_changed)

        # 작업 목록 트리뷰
        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        # 트리뷰
        self.tree = ttk.Treeview(
            tree_frame, columns=("type", "description"), show="tree headings", height=12
        )

        # 컬럼 설정
        self.tree.heading("#0", text="작업명")
        self.tree.heading("type", text="유형")
        self.tree.heading("description", text="설명")

        self.tree.column("#0", width=150)
        self.tree.column("type", width=100)
        self.tree.column("description", width=250)

        # 스크롤바
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.configure(command=self.tree.yview)

        # 이벤트 바인딩
        self.tree.bind("<Double-Button-1>", self._on_double_click)

        # 작업 설명 표시
        info_frame = ttk.LabelFrame(self, text="작업 정보", padding=5)
        info_frame.pack(fill=tk.X, pady=(10, 0))

        self.info_text = tk.Text(info_frame, height=3, wrap=tk.WORD, font=("Arial", 9))
        self.info_text.pack(fill=tk.X)
        self.info_text.config(state=tk.DISABLED)

        # 트리 선택 이벤트
        self.tree.bind("<<TreeviewSelect>>", self._on_selection_changed)

    def _get_available_tasks(self) -> List[Dict[str, Any]]:
        """사용 가능한 작업 목록"""
        return [
            # 기본 작업
            {
                "name": "네이버 로그인",
                "type": TaskType.LOGIN,
                "class": LoginTask,
                "category": "기본",
                "description": "네이버 계정으로 로그인합니다.",
                "icon": "🔐",
            },
            {
                "name": "대기",
                "type": TaskType.WAIT,
                "class": WaitTask,
                "category": "유틸리티",
                "description": "지정된 시간만큼 대기합니다.",
                "icon": "⏱️",
            },
            # 포스트 관련
            {
                "name": "이웃 새글 확인",
                "type": TaskType.CHECK_POSTS,
                "class": CheckNewPostsTask,
                "category": "포스트",
                "description": "이웃들의 새 글을 확인합니다.",
                "icon": "📋",
            },
            {
                "name": "댓글 작성",
                "type": TaskType.WRITE_COMMENT,
                "class": WriteCommentTask,
                "category": "포스트",
                "description": "포스트에 댓글을 작성합니다.",
                "icon": "💬",
            },
            {
                "name": "좋아요 클릭",
                "type": TaskType.CLICK_LIKE,
                "class": LikeTask,
                "category": "포스트",
                "description": "포스트에 좋아요를 클릭합니다.",
                "icon": "👍",
            },
            {
                "name": "스크롤 읽기",
                "type": TaskType.SCROLL_READ,
                "class": ScrollReadTask,
                "category": "포스트",
                "description": "포스트를 스크롤하며 읽습니다.",
                "icon": "📖",
            },
            # 유틸리티
            {
                "name": "URL 이동",
                "type": TaskType.GOTO_URL,
                "class": GoToUrlTask,
                "category": "유틸리티",
                "description": "지정된 URL로 이동합니다.",
                "icon": "🌐",
            },
        ]

    def _load_tasks(self):
        """작업 목록 로드"""
        # 기존 항목 제거
        for item in self.tree.get_children():
            self.tree.delete(item)

        # 작업 추가
        for task_info in self.filtered_tasks:
            icon = task_info.get("icon", "")
            name = f"{icon} {task_info['name']}" if icon else task_info["name"]

            self.tree.insert(
                "",
                "end",
                text=name,
                values=(task_info["type"].value, task_info["description"]),
                tags=(task_info["category"],),
            )

        # 태그별 색상 설정
        self.tree.tag_configure("기본", foreground="#0066cc")
        self.tree.tag_configure("포스트", foreground="#009900")
        self.tree.tag_configure("유틸리티", foreground="#cc6600")

    def _on_search_changed(self, *args):
        """검색어 변경 이벤트"""
        self._filter_tasks()

    def _on_category_changed(self, event):
        """카테고리 변경 이벤트"""
        self._filter_tasks()

    def _filter_tasks(self):
        """작업 필터링"""
        search_text = self.search_var.get().lower()
        category = self.category_var.get()

        self.filtered_tasks = []

        for task in self.available_tasks:
            # 카테고리 필터
            if category != "전체" and task["category"] != category:
                continue

            # 검색어 필터
            if search_text:
                if not any(
                    search_text in str(value).lower()
                    for value in [task["name"], task["description"]]
                ):
                    continue

            self.filtered_tasks.append(task)

        self._load_tasks()

    def _on_selection_changed(self, event):
        """선택 변경 이벤트"""
        selection = self.tree.selection()
        if not selection:
            self._show_info("")
            return

        item = self.tree.item(selection[0])
        task_name = item["text"].lstrip("🔐⏱️📋💬👍📖🌐 ")  # 아이콘 제거

        # 작업 정보 찾기
        task_info = next(
            (t for t in self.available_tasks if t["name"] == task_name), None
        )

        if task_info:
            info_text = f"작업: {task_info['name']}\n"
            info_text += f"카테고리: {task_info['category']}\n"
            info_text += f"설명: {task_info['description']}"
            self._show_info(info_text)

    def _show_info(self, text: str):
        """정보 표시"""
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(1.0, text)
        self.info_text.config(state=tk.DISABLED)

    def _on_double_click(self, event):
        """더블클릭 이벤트"""
        if self.on_task_double_click:
            task_info = self.get_selected_task()
            if task_info:
                self.on_task_double_click(task_info)

    def get_selected_task(self) -> Optional[Dict[str, Any]]:
        """선택된 작업 정보 반환"""
        selection = self.tree.selection()
        if not selection:
            return None

        item = self.tree.item(selection[0])
        task_name = item["text"].lstrip("🔐⏱️📋💬👍📖🌐 ")  # 아이콘 제거

        return next((t for t in self.available_tasks if t["name"] == task_name), None)

    def refresh(self):
        """목록 새로고침"""
        self._filter_tasks()
