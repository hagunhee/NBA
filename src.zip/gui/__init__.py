# src/gui/widgets/__init__.py
"""
GUI 위젯 모듈
"""
