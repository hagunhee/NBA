"""
작업 편집 다이얼로그
파일 위치: src/gui/dialogs/task_edit_dialog.py
"""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Optional
import json

from tasks.base_task import BaseTask, TaskType


class TaskEditDialog:
    """작업 편집 다이얼로그"""

    def __init__(self, parent, task: BaseTask):
        self.task = task
        self.result = False
        self.param_widgets = {}

        # 다이얼로그 생성
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(f"{task.name} 설정")
        self.dialog.geometry("600x700")
        self.dialog.resizable(True, True)

        # 중앙 배치
        self.dialog.transient(parent)
        self.dialog.grab_set()

        self._setup_ui()
        self._load_current_values()

        # 포커스 설정
        self.dialog.focus_set()

    def _setup_ui(self):
        """UI 구성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 작업 정보
        self._create_info_section(main_frame)

        # 파라미터 편집
        self._create_parameters_section(main_frame)

        # 버튼들
        self._create_buttons(main_frame)

    def _create_info_section(self, parent):
        """작업 정보 섹션"""
        info_frame = ttk.LabelFrame(parent, text="작업 정보", padding="10")
        info_frame.pack(fill=tk.X, pady=(0, 20))

        # 작업 이름
        name_frame = ttk.Frame(info_frame)
        name_frame.pack(fill=tk.X, pady=5)

        ttk.Label(name_frame, text="작업 이름:").pack(side=tk.LEFT)
        self.name_var = tk.StringVar(value=self.task.name)
        ttk.Entry(name_frame, textvariable=self.name_var, width=40).pack(
            side=tk.LEFT, padx=(10, 0)
        )

        # 작업 정보 표시
        info_text = f"유형: {self.task.type.value}\n"
        info_text += f"설명: {self.task.description}"

        ttk.Label(info_frame, text=info_text, foreground="gray").pack(
            anchor=tk.W, pady=(10, 0)
        )

    def _create_parameters_section(self, parent):
        """파라미터 섹션"""
        param_frame = ttk.LabelFrame(parent, text="파라미터", padding="10")
        param_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))

        # 스크롤 가능한 영역
        canvas = tk.Canvas(param_frame)
        scrollbar = ttk.Scrollbar(param_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # 파라미터 위젯 생성
        if hasattr(self.task, "get_required_parameters"):
            param_info = self.task.get_required_parameters()
            self._create_parameter_widgets(scrollable_frame, param_info)
        else:
            # 기본 파라미터 표시
            self._create_default_parameter_widgets(scrollable_frame)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def _create_parameter_widgets(self, parent, param_info: Dict[str, Dict[str, Any]]):
        """파라미터 위젯 생성"""
        for param_name, info in param_info.items():
            # 파라미터 프레임
            p_frame = ttk.Frame(parent)
            p_frame.pack(fill=tk.X, pady=10)

            # 라벨
            label_text = info.get("description", param_name)
            if info.get("required", False):
                label_text += " *"

            ttk.Label(p_frame, text=label_text).pack(anchor=tk.W)

            # 민감한 정보 표시
            if info.get("sensitive", False):
                ttk.Label(
                    p_frame, text="(보안 정보)", font=("Arial", 8), foreground="red"
                ).pack(anchor=tk.W)

            # 입력 위젯 생성
            widget = self._create_input_widget(p_frame, param_name, info)
            if widget:
                self.param_widgets[param_name] = widget

    def _create_default_parameter_widgets(self, parent):
        """기본 파라미터 위젯"""
        if not self.task.parameters:
            ttk.Label(
                parent, text="설정 가능한 파라미터가 없습니다.", foreground="gray"
            ).pack(pady=20)
            return

        # JSON 편집기
        ttk.Label(parent, text="파라미터 (JSON):").pack(anchor=tk.W)

        self.json_text = tk.Text(parent, height=10, width=60)
        self.json_text.pack(fill=tk.BOTH, expand=True, pady=5)

        # 현재 파라미터를 JSON으로 표시
        json_str = json.dumps(self.task.parameters, indent=2, ensure_ascii=False)
        self.json_text.insert(1.0, json_str)

    def _create_input_widget(self, parent, param_name: str, info: Dict[str, Any]):
        """입력 위젯 생성"""
        param_type = info.get("type", "string")
        current_value = self.task.get_parameter(param_name, info.get("default"))

        widget_frame = ttk.Frame(parent)
        widget_frame.pack(fill=tk.X, pady=2)

        if param_type == "string":
            widget = ttk.Entry(widget_frame, width=50)
            widget.insert(0, current_value or "")
            widget.pack(side=tk.LEFT)
            return widget

        elif param_type == "password":
            widget = ttk.Entry(widget_frame, width=50, show="*")
            widget.insert(0, current_value or "")
            widget.pack(side=tk.LEFT)

            # 표시/숨기기 버튼
            show_var = tk.BooleanVar(value=False)

            def toggle_show():
                widget.config(show="" if show_var.get() else "*")

            ttk.Checkbutton(
                widget_frame, text="표시", variable=show_var, command=toggle_show
            ).pack(side=tk.LEFT, padx=(10, 0))

            return widget

        elif param_type == "integer":
            min_val = info.get("min", 0)
            max_val = info.get("max", 9999)

            widget = ttk.Spinbox(widget_frame, from_=min_val, to=max_val, width=20)
            widget.set(current_value)
            widget.pack(side=tk.LEFT)
            return widget

        elif param_type == "float":
            widget = ttk.Entry(widget_frame, width=20)
            widget.insert(0, str(current_value))
            widget.pack(side=tk.LEFT)

            ttk.Label(widget_frame, text="(소수점 사용 가능)").pack(
                side=tk.LEFT, padx=(10, 0)
            )
            return widget

        elif param_type == "boolean":
            var = tk.BooleanVar(value=current_value)
            widget = ttk.Checkbutton(widget_frame, variable=var)
            widget.var = var  # 변수 참조 저장
            widget.pack(side=tk.LEFT)
            return widget

        elif param_type == "choice":
            choices = info.get("choices", [])
            widget = ttk.Combobox(
                widget_frame, values=choices, state="readonly", width=30
            )
            widget.set(current_value)
            widget.pack(side=tk.LEFT)
            return widget

        elif param_type == "list":
            # 리스트 편집 위젯
            list_frame = ttk.Frame(widget_frame)
            list_frame.pack(fill=tk.BOTH, expand=True)

            # 텍스트 영역
            widget = tk.Text(list_frame, width=50, height=4)
            widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

            # 현재 값 표시
            if current_value:
                widget.insert(1.0, "\n".join(str(item) for item in current_value))

            # 스크롤바
            scrollbar = ttk.Scrollbar(list_frame, command=widget.yview)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            widget.config(yscrollcommand=scrollbar.set)

            # 도움말
            ttk.Label(
                parent,
                text="(한 줄에 하나씩 입력)",
                font=("Arial", 8),
                foreground="gray",
            ).pack(anchor=tk.W)

            return widget

        return None

    def _create_buttons(self, parent):
        """버튼 생성"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X)

        # 왼쪽: 리셋 버튼
        ttk.Button(
            button_frame, text="기본값으로 리셋", command=self._reset_to_defaults
        ).pack(side=tk.LEFT)

        # 오른쪽: 저장/취소
        ttk.Button(button_frame, text="저장", command=self._save).pack(
            side=tk.RIGHT, padx=(5, 0)
        )

        ttk.Button(button_frame, text="취소", command=self.dialog.destroy).pack(
            side=tk.RIGHT
        )

    def _load_current_values(self):
        """현재 값 로드"""
        # 이미 위젯 생성 시 로드됨
        pass

    def _reset_to_defaults(self):
        """기본값으로 리셋"""
        result = messagebox.askyesno(
            "확인", "모든 파라미터를 기본값으로 리셋하시겠습니까?"
        )

        if not result:
            return

        # 기본값 가져오기
        if hasattr(self.task, "get_required_parameters"):
            param_info = self.task.get_required_parameters()

            for param_name, widget in self.param_widgets.items():
                if param_name in param_info:
                    default = param_info[param_name].get("default", "")
                    self._set_widget_value(widget, default)

    def _set_widget_value(self, widget, value):
        """위젯 값 설정"""
        if isinstance(widget, ttk.Entry):
            widget.delete(0, tk.END)
            widget.insert(0, str(value) if value is not None else "")
        elif isinstance(widget, ttk.Spinbox):
            widget.set(value)
        elif isinstance(widget, ttk.Checkbutton):
            widget.var.set(bool(value))
        elif isinstance(widget, ttk.Combobox):
            widget.set(value)
        elif isinstance(widget, tk.Text):
            widget.delete(1.0, tk.END)
            if isinstance(value, list):
                widget.insert(1.0, "\n".join(str(item) for item in value))
            else:
                widget.insert(1.0, str(value) if value else "")

    def _save(self):
        """설정 저장"""
        try:
            # 작업 이름 업데이트
            new_name = self.name_var.get().strip()
            if new_name:
                self.task.name = new_name

            # 파라미터 수집
            if self.param_widgets:
                self._save_structured_parameters()
            elif hasattr(self, "json_text"):
                self._save_json_parameters()

            # 파라미터 검증
            if hasattr(self.task, "validate_parameters"):
                if not self.task.validate_parameters():
                    messagebox.showerror("오류", "잘못된 파라미터 값입니다.")
                    return

            self.result = True
            self.dialog.destroy()

        except Exception as e:
            messagebox.showerror("오류", f"설정 저장 실패: {str(e)}")

    def _save_structured_parameters(self):
        """구조화된 파라미터 저장"""
        for param_name, widget in self.param_widgets.items():
            value = self._get_widget_value(widget)
            self.task.set_parameters(**{param_name: value})

    def _get_widget_value(self, widget):
        """위젯 값 가져오기"""
        if isinstance(widget, ttk.Entry):
            return widget.get()
        elif isinstance(widget, ttk.Spinbox):
            try:
                return int(widget.get())
            except ValueError:
                return 0
        elif isinstance(widget, ttk.Checkbutton):
            return widget.var.get()
        elif isinstance(widget, ttk.Combobox):
            return widget.get()
        elif isinstance(widget, tk.Text):
            text = widget.get(1.0, tk.END).strip()
            # 리스트로 변환
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            return lines

        return None

    def _save_json_parameters(self):
        """JSON 파라미터 저장"""
        json_str = self.json_text.get(1.0, tk.END).strip()

        try:
            params = json.loads(json_str)
            if isinstance(params, dict):
                self.task.parameters = params
            else:
                raise ValueError("파라미터는 딕셔너리 형식이어야 합니다.")
        except json.JSONDecodeError as e:
            raise ValueError(f"잘못된 JSON 형식: {str(e)}")
