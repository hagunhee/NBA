# src/gui/dialogs/__init__.py
from .task_edit_dialog import TaskEditDialog
from .license_dialog import LicenseDialog
from .help_dialog import HelpDialog

__all__ = ["TaskEditDialog", "LicenseDialog", "HelpDialog"]
